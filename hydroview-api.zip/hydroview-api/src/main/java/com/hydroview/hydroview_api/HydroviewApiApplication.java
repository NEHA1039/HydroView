package com.hydroview.hydroview_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HydroviewApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HydroviewApiApplication.class, args);
	}

}
