package com.hydroview.hydroview_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HydroviewApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
